#include <fx.h>
#include <ice2k/comctl32.h>
#include <ice2k/branding.h>
#include "res/foxres.h"
#include <dirent.h>

#include <X11/Xlib.h>
#include <X11/extensions/Xrandr.h>


#include <stdio.h>
#include <string.h>
#include <cpuid.h>
#include <sys/sysinfo.h>
#include <stdint.h>
#include <locale.h>
#include <unistd.h>
#include <limits.h>

#include <ifaddrs.h>
#include <net/if.h>
#include <netdb.h>
#include <errno.h>


#include <sys/types.h>
#include <pwd.h>
#include <ctype.h>
#include <fcntl.h>

extern "C" {
#include <pci/pci.h>
}

FXApp* app;

#define _SYSFS_BLOCK "/sys/block"

FXMainWindow* sysdmwin;
FXIcon* ico_devmgmt;

int getIPAddress(char* str) // taken from hostname utility, slightly modified
{                           // only returns 1 ipv4 address
	struct ifaddrs *ifa, *ifap;
	//char *p;
	char buf[NI_MAXHOST];
	int flags, ret, family, addrlen;

	flags = NI_NUMERICHOST;

	if (getifaddrs(&ifa) != 0) {
		fprintf(stderr, "%s", strerror(errno));
		return errno;
	}

	for (ifap = ifa; ifap != NULL; ifap = ifap->ifa_next) {
		/* Skip interfaces that have no configured addresses */
		if (ifap->ifa_addr == NULL)
			continue;

		/* Skip the loopback interface */
		if (ifap->ifa_flags & IFF_LOOPBACK)
			continue;

		/* Skip interfaces that are not UP */
		if (!(ifap->ifa_flags & IFF_UP))
			continue;

		/* Only handle IPv4 addresses */
		family = ifap->ifa_addr->sa_family;
		if (family != AF_INET)
			continue;

		addrlen = (family == AF_INET) ? sizeof(struct sockaddr_in) :
		                                sizeof(struct sockaddr_in6);

		ret = getnameinfo(ifap->ifa_addr, addrlen,
		                  buf, sizeof(buf), NULL, 0, flags);

		/* Just skip addresses that cannot be translated */
		if (ret != 0) {
			if (ret != EAI_NONAME) {
				fprintf(stderr, "%s", gai_strerror(ret));
				return ret;
			}
		} else {
			strcpy(str, buf);
			break;
		}
	}
	freeifaddrs(ifa);
	return 0;
}

// thank you https://en.wikipedia.org/wiki/CPUID#EAX=8000'0002h,8000'0003h,8000'0004h:_Processor_Brand_String
int getCpuString(char* output) {
  #ifdef __x86_64__
    #define _CPUID
  #endif

  #ifdef __i386__
    #define _CPUID
  #endif

  #ifdef _CPUID
    unsigned int regs[12];      // i know i can use the linux apis for this...
                                // but that's boring and i want to have fun :P
    __cpuid(0x80000000, regs[0], regs[1], regs[2], regs[3]);

    if (regs[0] < 0x80000004)
      return 1;

    __cpuid(0x80000002, regs[0], regs[1], regs[2], regs[3]);
    __cpuid(0x80000003, regs[4], regs[5], regs[6], regs[7]);
    __cpuid(0x80000004, regs[8], regs[9], regs[10], regs[11]);

    memcpy(output, regs, sizeof(regs));
    output[sizeof(regs)] = '\0';

    return 0;
  #else
    return 1;
  #endif
}

// https://stackoverflow.com/questions/22582989/word-wrap-program-c
inline int wordlen(const char * str){
  int tempindex=0;
  while (str[tempindex]!=' ' && str[tempindex]!=0 && str[tempindex]!='\n') {
    ++tempindex;
  }
  return(tempindex);
}

void wrap(char * s, const int wrapline){
  int index = 0;
  int curlinelen = 0;
  
  while (s[index] != '\0') {
    if (s[index] == '\n')
      curlinelen = 0;

    else if (s[index] == ' ') {
      if (curlinelen+wordlen(&s[index+1]) >= wrapline) {
        s[index] = '\n';
        curlinelen = 0;
      }
    }

    curlinelen++;
    index++;
  }
}

void formatnum(long unsigned num, char *buffer) { // from ice2kver
  char temp[1024];
  sprintf(temp, "%lu", num / 1024);

  int len = strlen(temp);
  int commas = (len - 1) / 3;
  int new_len = len + commas;

  buffer[new_len] = '\0';
  int i = len - 1, j = new_len - 1;

  int count = 0;
  while (i >= 0) {
    if (count == 3) {
      buffer[j--] = ',';
      count = 0;
    }
    buffer[j--] = temp[i--];
    count++;
  }
}


class ChangeHostnameBox : public FXDialogBox {
	FXDECLARE(ChangeHostnameBox)

	private:
		// Controls
		FXHorizontalFrame *cont;                 // Container

		FXLabel           *icon;                 // About icon
		FXLabel           *text;                 // About text

		FXButton          *okbtn;                // OK button
		FXButton          *cancelbtn;            // Cancel button
								     //
		FXTextField       *compfield;

	protected:
		ChangeHostnameBox() {}

public:

  // Message handlers
  long onSetFocus(FXObject*,FXSelector,void*);


public:

  // Messages for our class
  enum {
    ID_MAINWIN=FXMainWindow::ID_LAST,
    ID_SETFOCUS_T
  };

	public:

		// ChangeHostnameBox's constructor
		ChangeHostnameBox(FXWindow* owner);

		// Initialize
		virtual void create();

		virtual ~ChangeHostnameBox();
};



// Change computer name window
FXDEFMAP(ChangeHostnameBox) ChangeHostnameBoxMap[] = {
  FXMAPFUNC(SEL_TIMEOUT, ChangeHostnameBox::ID_SETFOCUS_T, ChangeHostnameBox::onSetFocus),
};

FXIMPLEMENT(ChangeHostnameBox,FXDialogBox,ChangeHostnameBoxMap,ARRAYNUMBER(ChangeHostnameBoxMap))


long ChangeHostnameBox::onSetFocus(FXObject* sender, FXSelector sel, void* ptr) {
  this->setFocus();
  //puts("a");
  return 1;
}


/* int checkAcpiSupport() {
	DIR* dir;
	dir = opendir("/sys/class/acpi");

	if (dir) {
		closedir(dir);
		dir = opendir("/proc/acpi");

		if (dir) {
			closedir(dir);
			dir = opendir("/sys/firmware/acpi");

			if (dir) {
				closedir(dir);
				return 0;
			}
		}
	}

	return 1;
} */


int checkAcpiSupport() {
	int i = 0;
	DIR* dir;

	acpicheck:

	switch(i) {
		case 0:
			dir = opendir("/sys/module/acpi");
			break;

		case 1:
			dir = opendir("/proc/acpi");
			break;

		case 2:
			dir = opendir("/sys/firmware/acpi");
			break;

		default:
			return 0;
	}

	closedir(dir);

	if (!dir) {
		return 1;
	}

	i++;

	goto acpicheck;
}

int checkAmd64() {
	// this ones easy...
	
	#ifdef __x86_64__
		//puts("System is 64 bit");
		return 0;
	#else
		return 1;
	#endif
}

// taken from ice2k batmeter
int getHardDrives(char *buf, int bufsize) {
	DIR *dir = opendir(_SYSFS_BLOCK);
	struct dirent *entry;
	//size_t len = 0;
	int len = 0;

	if (!dir) {
		perror("opendir");
		if (bufsize > 0) buf[0] = '\0';
		return 1;
	}

	buf[0] = '\0';

	while ((entry = readdir(dir)) != NULL) {
		if ((strncmp(entry->d_name, "sd", 2)) && (strncmp(entry->d_name, "hd", 2)))
			continue;

		char full_path[255 + 12];
		snprintf(full_path, sizeof(full_path), "%s/%s", _SYSFS_BLOCK, entry->d_name);

		//size_t entry_len = strlen(entry->d_name);
		int entry_len = strlen(entry->d_name);

		if (len > 0) {
			if (len + 1 < bufsize) {
				buf[len] = ',';
				len++;
				buf[len] = '\0';
			} else {
				break;
			}
		}

		if (len + entry_len < bufsize) {
			strcat(buf, entry->d_name);
			len += entry_len;
		} else {
			break;
		}
	}

	closedir(dir);

	return 0;
}

// taken from ice2k batmeter
int getHddInfo(const char* hardDrive, const char* info, char* buf, int bufsize ) {
	char hddpath[64];
	int fd;
	int len = 0;

	snprintf(hddpath, sizeof(hddpath), "%s/%s/%s", _SYSFS_BLOCK, hardDrive, info);

	fd = open(hddpath, O_RDONLY);

	if (fd < 0) {
		return 1;
	}

	len = read(fd, buf, bufsize - 1);
	if (len < 0) {
		close(fd);
		return 1;
	}

	buf[len] = '\0';

	for (int i = 0; buf[i] != '\0'; ++i) {
		if (buf[i] == '\n') {
			buf[i] = '\0';
			break;
		}
	}

	close(fd);
	return 0;
}

// i want to thank chatgpt for xrandr docs
// theres virtually no documentation for xrandr's api aside from the official ones

int getMonitors(char* buf, int bufsize ) {
//int getMonitors() {
	Display* dpy = (Display*)app->getDisplay();
	Window root = DefaultRootWindow(dpy);

	int eventBase, errorBase;
	XRRScreenResources* resources;

	if (!XRRQueryExtension(dpy, &eventBase, &errorBase))
		return 1;

	resources = XRRGetScreenResources(dpy, root);

	if (!resources)
		return 1;

	int y = 0;

	for (int i = 0; i < resources->noutput; i++) {
		XRROutputInfo *outputInfo = XRRGetOutputInfo(dpy, resources, resources->outputs[i]);
		if (outputInfo->connection == RR_Connected) {
			if (y) {
				strcat(buf, ",");
				strncat(buf, outputInfo->name, sizeof(buf));
			} else {
				strcpy(buf, outputInfo->name);
			}
			y = 1;
		}
	}

	return 0;
}

ChangeHostnameBox::ChangeHostnameBox(FXWindow* owner):

FXDialogBox(owner, "Identification Changes", DECOR_TITLE|DECOR_BORDER|DECOR_CLOSE|DECOR_MENU, 0, 0, 0, 0,
                                  11, 12, 11, 11, 0, 0) {
	new FXLabel(this, "You can change the name of this computer. You must install", NULL, LABEL_NORMAL|JUSTIFY_LEFT, 0,0,0,0,  1,0,0,-1);
	new FXLabel(this, "networking before you can change this computer's domain", NULL, LABEL_NORMAL|JUSTIFY_LEFT, 0,0,0,0,  1,0,0,-1);
	new FXLabel(this, "membership.", NULL, LABEL_NORMAL|JUSTIFY_LEFT, 0,0,0,0,  1,0,0,0);
	new FXSeparator(this, SEPARATOR_NONE|LAYOUT_FIX_HEIGHT, 0,0,0,19);

	char hostname[HOST_NAME_MAX+1];
	gethostname(hostname, HOST_NAME_MAX+1);

	new FXLabel(this, "&Computer name:", NULL, LABEL_NORMAL|JUSTIFY_LEFT, 0,0,0,0,  1,0,0,2);

	compfield = new FXTextField(this, 49,NULL,0,FRAME_SUNKEN|FRAME_THICK);
	//com�Qpfield->setFocus();

	compfield->setText(hostname);
	compfield->selectAll();

	new FXSeparator(this, SEPARATOR_NONE|LAYOUT_FIX_HEIGHT, 0,0,0,86); // why so much whitespace?
												 //
	FXGroupBox* membergrp = new FXGroupBox(this, "Member of", FRAME_THICK|LAYOUT_FILL_X, 0,0,0,0, 12,12,2,12);
	FXRadioButton* domainrad = new FXRadioButton(membergrp, "&Domain:", NULL, 0, RADIOBUTTON_NORMAL, 0,0,0,0,  2,0,2,0);
	domainrad->disable();
	FXTextField* domaintxt = new FXTextField(membergrp, 41, NULL, 0, LAYOUT_FIX_X|TEXTFIELD_NORMAL, 31,0,0,0,  2,2,2,1);
	domaintxt->disable();
	FXRadioButton* workgrad = new FXRadioButton(membergrp, "&Workgroup:", NULL, 0, RADIOBUTTON_NORMAL, 0,0,0,0,  2,0,4,0);
	workgrad->setCheck(TRUE);
	workgrad->disable();
	FXTextField* worktxt = new FXTextField(membergrp, 41, NULL, 0, LAYOUT_FIX_X|TEXTFIELD_NORMAL, 31,0,0,0,  2,2,2,1);
	worktxt->setText("WORKGROUP");
	worktxt->setTextColor(getApp()->getShadowColor());
	worktxt->disable();
	membergrp->disable();


	new FXSeparator(this, SEPARATOR_NONE|LAYOUT_FIX_HEIGHT, 0,0,0,9);

	//membergrp->disable();

	FXHorizontalFrame* btncont = new FXHorizontalFrame(this, LAYOUT_RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0);

	okbtn = new FXButton(btncont, "OK", NULL, this, ID_ACCEPT,
	BUTTON_DEFAULT|BUTTON_INITIAL|FRAME_THICK|FRAME_RAISED|LAYOUT_FIX_WIDTH|LAYOUT_FIX_HEIGHT,
	0, 0, 75, 23, 3, 3, 2, 3);

	cancelbtn = new FXButton(btncont, "Cancel", NULL, this, ID_CANCEL,
	BUTTON_DEFAULT|FRAME_THICK|FRAME_RAISED|LAYOUT_FIX_WIDTH|LAYOUT_FIX_HEIGHT,
	0, 0, 75, 23, 3, 3, 2, 3);
  getApp()->addTimeout(this,ChangeHostnameBox::ID_SETFOCUS_T,10); // hacky but only reliable way i found to do it...

	//okbtn->setFocus();
}


ChangeHostnameBox::~ChangeHostnameBox() {
}

void ChangeHostnameBox::create() {
	FXDialogBox::create();
	compfield->setFocus();
}



// Main Window
class SystemPropertiesWindow : public FXMainWindow {

  // Macro for class hierarchy declarations
  FXDECLARE(SystemPropertiesWindow)

private:
  FXVerticalFrame*          generalframe;
  FXVerticalFrame*          networkframe;
  FXVerticalFrame*          hardwareframe;
  FXVerticalFrame*          userframe;
  FXVerticalFrame*          advframe;

  FXHorizontalFrame*        btncont;
  FXTabBook*                tabbook;
  FXButton*                 okbtn;
  FXButton*                 cancelbtn;
  FXButton*                 applybtn;

  FXHorizontalFrame*        horcont;
  FXVerticalFrame*          vercont;



protected:
  SystemPropertiesWindow(){}

public:

  // Message handlers
  long onAccept(FXObject*,FXSelector,void*);
  long onChangeHostname(FXObject*,FXSelector,void*);
  long onCmdEnvVars(FXObject*,FXSelector,void*);
  long onCmdNtldr(FXObject*,FXSelector,void*);
  long onSetFocus(FXObject*,FXSelector,void*);
  long onUnFocus(FXObject*,FXSelector,void*);


public:

  // Messages for our class
  enum {
    ID_MAINWIN=FXMainWindow::ID_LAST,
    ID_CHANGEHOSTNAME,
    ID_ACCEPT,
    ID_CANCEL,
    ID_ENVVARS,
    ID_NTLDR,
    ID_SETFOCUS_T,
    ID_UNFOCUS_T
  };

public:

  // CtrlAltDelWindow's constructor
  SystemPropertiesWindow(FXApp* a);

  // Initialize
  virtual void create();

  virtual ~SystemPropertiesWindow();
};

FXDEFMAP(SystemPropertiesWindow) SystemPropertiesWindowMap[] = {
  FXMAPFUNC(SEL_COMMAND, SystemPropertiesWindow::ID_ACCEPT, SystemPropertiesWindow::onAccept),
  FXMAPFUNC(SEL_COMMAND, SystemPropertiesWindow::ID_CANCEL, SystemPropertiesWindow::onAccept),
  FXMAPFUNC(SEL_COMMAND, SystemPropertiesWindow::ID_CHANGEHOSTNAME, SystemPropertiesWindow::onChangeHostname),
  FXMAPFUNC(SEL_COMMAND, SystemPropertiesWindow::ID_ENVVARS, SystemPropertiesWindow::onCmdEnvVars),
  FXMAPFUNC(SEL_COMMAND, SystemPropertiesWindow::ID_NTLDR, SystemPropertiesWindow::onCmdNtldr),

  FXMAPFUNC(SEL_TIMEOUT, SystemPropertiesWindow::ID_SETFOCUS_T, SystemPropertiesWindow::onSetFocus),
  FXMAPFUNC(SEL_TIMEOUT, SystemPropertiesWindow::ID_UNFOCUS_T, SystemPropertiesWindow::onUnFocus),
};

FXIMPLEMENT(SystemPropertiesWindow,FXMainWindow,SystemPropertiesWindowMap,ARRAYNUMBER(SystemPropertiesWindowMap))



SystemPropertiesWindow::~SystemPropertiesWindow() {
}

long SystemPropertiesWindow::onSetFocus(FXObject* sender, FXSelector sel, void* ptr) {
  this->killFocus();
  this->setFocus();

  //puts("a");
  return 1;
}
long SystemPropertiesWindow::onUnFocus(FXObject* sender, FXSelector sel, void* ptr) {
  this->setFocus();
  //puts("a");
  return 1;
}

void SystemPropertiesWindow::create() {
  FXMainWindow::create();
}


long SystemPropertiesWindow::onAccept(FXObject* sender, FXSelector sel, void* ptr) {
  this->close();
  return 0;
}

long SystemPropertiesWindow::onCmdEnvVars(FXObject* sender, FXSelector sel, void* ptr) {


  system("xfw ~/.profile &"); // there is no good way of finding out where env vars are set on linux
  return 1;                   // and to globally set them because linux SUCKS
}

long SystemPropertiesWindow::onCmdNtldr(FXObject* sender, FXSelector sel, void* ptr) {
  //getApp()->beginWaitCursor();
  if (access("/boot/extlinux/extlinux.conf", F_OK) == 0)
    system("xfw /boot/extlinux/extlinux.conf &");
  else if (access("/boot/efi/loader/loader.conf", F_OK) == 0)
    system("xfw /boot/efi/loader/loader.conf &");
  else
    system("xfw /etc/default/grub &");

  /* if (access("/boot/extlinux/extlinux.conf", F_OK) == 0)
    system("xfw /boot/extlinux/extlinux.conf &");
  else if (access("/boot/efi/loader/loader.conf", F_OK) == 0)
    system("xfw /boot/efi/loader/loader.conf &");
  else
    system("xfw /etc/default/grub &"); */

  //getApp()->endWaitCursor();
  return 1;
}

long SystemPropertiesWindow::onChangeHostname(FXObject* sender, FXSelector sel, void* ptr) {
  ChangeHostnameBox* hostnamebox = new ChangeHostnameBox(sysdmwin);
  hostnamebox->execute(PLACEMENT_OWNER);
  return 1;
}

void getComputerName(char* computerType, int size) {
    // asked chatgpt to clean it up, did it's job well. was a bunch of nested ifs before
    int acpiSupport = checkAcpiSupport();
    int amd64Cpu = checkAmd64();
    int multiProcessor = 0;

    if (get_nprocs_conf() > 1)
      multiProcessor = 1;

    const char* arch = amd64Cpu ? "" : " x64-based";
    const char* biosType;

    if (!acpiSupport) {
      biosType = multiProcessor ? "ACPI Multiprocessor"
                                : "Advanced Configuration and Power Interface (ACPI)";
    } else {
      biosType = multiProcessor ? "MPS Multiprocessor"
                                : "Standard";
    }

    snprintf(computerType, size, "%s%s PC", biosType, arch);
}


//int main(int argc, char *argv[]) {
SystemPropertiesWindow::SystemPropertiesWindow(FXApp *app):FXMainWindow(app, "Device Manager", ico_devmgmt, NULL, DECOR_ALL, 0,0,480,320,  0,0,0,0,  0,0) {
  FXDockSite* topdock = new FXDockSite(this, FRAME_SUNKEN|DOCKSITE_NO_WRAP|LAYOUT_SIDE_TOP|LAYOUT_FILL_X);

  // Menubar

    FXPacker* statusbarcont = new FXPacker(this, JUSTIFY_LEFT|LAYOUT_FILL_X|LAYOUT_SIDE_BOTTOM, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
    new FXFrame(this, LAYOUT_FILL_X|LAYOUT_BOTTOM|LAYOUT_FIX_HEIGHT|LAYOUT_SIDE_BOTTOM, 0, 0, 0, 2, 0, 0, 0, 0);

    FXStatusBar* statusbar = new FXStatusBar(statusbarcont, LAYOUT_FILL_X|LAYOUT_FIX_Y|LAYOUT_FIX_X, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    FXPacker* corner = new FXPacker(statusbarcont, LAYOUT_FIX_WIDTH|LAYOUT_FIX_HEIGHT|LAYOUT_SIDE_RIGHT|LAYOUT_BOTTOM, 0, 0, 13, 13, 0, 0, 0, 0, 0, 0);
    FXDragCorner* realcorner = new FXDragCorner(corner);

  FXToolBarShell* mbshell = new FXToolBarShell(this,FRAME_SUNKEN);


  FXMenuBar* menubar = new FXMenuBar(topdock,mbshell,LAYOUT_DOCK_SAME|LAYOUT_SIDE_TOP|LAYOUT_FILL_Y|FRAME_RAISED);
  new FXToolBarGrip(menubar,menubar,FXMenuBar::ID_TOOLBARGRIP,TOOLBARGRIP_SINGLE);

  FXMenuPane* actionmenu = new FXMenuPane(this);
  FXMenuPane* viewmenu = new FXMenuPane(this);

  new FXMenuTitle(menubar, "&Action", NULL, actionmenu);
  new FXMenuCommand(actionmenu, "&Help");

  new FXMenuTitle(menubar, "&View", NULL, viewmenu);

  new FXMenuCommand(viewmenu, "D&evices by type\t\tDisplays devices by hardware type.");
  new FXMenuCommand(viewmenu, "De&vices by connection\t\tDisplays devices by connection.");
  new FXMenuCommand(viewmenu, "Resources by t&ype\t\tDisplays resources by type.");
  new FXMenuCommand(viewmenu, "Resources by co&nnection\t\tDisplays resources by connection");

  new FXMenuSeparator(viewmenu);

  new FXMenuCommand(viewmenu, "Sho&w hidden devices\t\tDisplays legacy devices and devices that are no longer installed.");

  new FXMenuSeparator(viewmenu);
  new FXMenuCommand(viewmenu, "&Print\t\tPrints a report of the devices that are installed.");
  new FXMenuSeparator(viewmenu);
  new FXMenuCommand(viewmenu, "C&ustomize...\t\tCustomizes the view");

  // Toolbar
  FXToolBarShell* tbshell = new FXToolBarShell(this,FRAME_SUNKEN);

  FXToolBar* toolbar = new FXMenuBar(topdock,tbshell,LAYOUT_FILL_Y|LAYOUT_DOCK_SAME|LAYOUT_SIDE_TOP|LAYOUT_FILL_X|FRAME_RAISED,0,0,0,0, 0,0,0,0,  1,1);
  new FXToolBarGrip(toolbar, toolbar, FXToolBar::ID_TOOLBARGRIP, TOOLBARGRIP_SINGLE,0,0,0,0,3,3,2,2);

  FXIcon* ico_back = new FXGIFIcon(app, resico_mmc_back);
  FXIcon* ico_forward = new FXGIFIcon(app, resico_mmc_forward);

  FXIcon* ico_up = new FXGIFIcon(app, resico_mmc_up);
  FXIcon* ico_contree = new FXGIFIcon(app, resico_mmc_contree);

  FXIcon* ico_help = new FXGIFIcon(app, resico_mmc_help);
  

  //FXIcon* ico_hist_up = new FXGIFIcon(app, resico_hist_up);
  FXButton* btn;

  btn = new FXButton(toolbar,"\tBack",ico_back,NULL,0,BUTTON_TOOLBAR|FRAME_RAISED|LAYOUT_TOP|LAYOUT_LEFT,0,0,0,0,  2,2,2,2);
  btn->disable();
  btn = new FXButton(toolbar,"\tForward",ico_forward,NULL,0,BUTTON_TOOLBAR|FRAME_RAISED|LAYOUT_TOP|LAYOUT_LEFT,0,0,0,0,  2,2,2,2);
  btn->disable();
  new FXVerticalSeparator(toolbar, SEPARATOR_GROOVE|LAYOUT_FILL_Y, 0,0,0,0,  2,2,1,1);
  btn = new FXButton(toolbar,"\tUp one level",ico_up,NULL,0,BUTTON_TOOLBAR|FRAME_RAISED|LAYOUT_TOP|LAYOUT_LEFT,0,0,0,0,  2,2,2,2);
  btn->disable();
  btn = new FXButton(toolbar,"\tShow/Hide Console Tree/Favorites",ico_contree,NULL,0,BUTTON_TOOLBAR|FRAME_RAISED|LAYOUT_TOP|LAYOUT_LEFT,0,0,0,0,  2,2,2,2);
  new FXVerticalSeparator(toolbar, SEPARATOR_GROOVE|LAYOUT_FILL_Y, 0,0,0,0,  2,2,1,1);

  btn = new FXButton(toolbar,"\tHelp",ico_help,NULL,0,BUTTON_TOOLBAR|FRAME_RAISED|LAYOUT_TOP|LAYOUT_LEFT,0,0,0,0,  2,2,2,2);

  new FXSeparator(this, SEPARATOR_NONE|LAYOUT_FIX_HEIGHT, 0,0,0,2); // semantics r cute  

  FXIcon* ico_dev_computer = new FXGIFIcon(app, resico_dev_computer);
  FXIcon* ico_dev_disk = new FXGIFIcon(app, resico_dev_disk);
  FXIcon* ico_dev_disp = new FXGIFIcon(app, resico_dev_disp);
  FXIcon* ico_dev_ide = new FXGIFIcon(app, resico_dev_ide);
  FXIcon* ico_dev_floppy = new FXGIFIcon(app, resico_dev_floppy);
  FXIcon* ico_dev_mice = new FXGIFIcon(app, resico_dev_mice);
  FXIcon* ico_dev_keyb = new FXGIFIcon(app, resico_dev_keyb);
  FXIcon* ico_dev_network = new FXGIFIcon(app, resico_dev_network);
  FXIcon* ico_dev_unknown = new FXGIFIcon(app, resico_dev_unknown);
  FXIcon* ico_dev_serial = new FXGIFIcon(app, resico_dev_serial);
  FXIcon* ico_dev_sound = new FXGIFIcon(app, resico_dev_sound);

  FXPacker* treeframe = new FXPacker(this, FRAME_THICK|FRAME_SUNKEN|LAYOUT_FILL_Y|LAYOUT_FILL_X, 0,0,0,0,  0,0,0,0);
  FXTreeList* tree = new FXTreeList(treeframe,NULL,0,SCROLLERS_DONT_TRACK|FRAME_SUNKEN|FRAME_THICK|LAYOUT_FILL_X|LAYOUT_FILL_Y|TREELIST_SHOWS_BOXES|TREELIST_SHOWS_LINES|TREELIST_BROWSESELECT|TREELIST_ROOT_BOXES);

  FXTreeItem *branch, *top;

  char hostname[HOST_NAME_MAX+1];
  gethostname(hostname, HOST_NAME_MAX+1);

  char *upper = hostname;

  while (*upper) {
    *upper = toupper((unsigned char) *upper);
    upper++;
  }

  // pci related code is based off here
  // thank you https://josuedhg.wordpress.com/2014/11/15/how-to-list-pci-devices-with-c-on-linux/

  struct pci_access* pciaccess;
  struct pci_dev* dev;
  char namebuf[1024];

  pciaccess = pci_alloc();
  pci_init(pciaccess);
  pci_scan_bus(pciaccess);

  top = tree->appendItem(0,hostname,ico_devmgmt,ico_devmgmt);
  tree->expandTree(top);
    char computerType[64];
    getComputerName(computerType, sizeof(computerType));

    branch = tree->appendItem(top,"Computer",ico_dev_computer,ico_dev_computer);    
      tree->appendItem(branch,computerType,ico_dev_computer,ico_dev_computer);


    char hardDrives[256];
    getHardDrives(hardDrives, sizeof(hardDrives));

    char* hardDrive = strtok(hardDrives, ",");

    char hardDriveModel[256];

    //puts(hardDrives);

    branch = tree->appendItem(top,"Disk drives",ico_dev_disk,ico_dev_disk);
      while (hardDrive) {
        getHddInfo(hardDrive, "device/model", hardDriveModel, sizeof(hardDriveModel));
        tree->appendItem(branch,hardDriveModel,ico_dev_disk,ico_dev_disk);
        hardDrive = strtok(NULL, ",");
      }



    FXTreeItem* devVga = tree->appendItem(top,"Display adapters",ico_dev_disp,ico_dev_disp);
    branch = tree->appendItem(top,"Floppy disk controllers",ico_dev_ide,ico_dev_ide);
    branch = tree->appendItem(top,"Floppy disk drives",ico_dev_floppy,ico_dev_floppy);
    FXTreeItem* devStorage = tree->appendItem(top,"IDE ATA/ATAPI controllers",ico_dev_ide,ico_dev_ide);
    branch = tree->appendItem(top,"Keyboards",ico_dev_keyb,ico_dev_keyb);
    branch = tree->appendItem(top,"Mice and other pointing devices",ico_dev_mice,ico_dev_mice);
    FXTreeItem* devMonitors = tree->appendItem(top,"Monitors",ico_dev_disp,ico_dev_disp);
    FXTreeItem* devNetwork = tree->appendItem(top,"Network adapters",ico_dev_network,ico_dev_network);
    FXTreeItem* devUnknown = tree->appendItem(top,"Other devices",ico_dev_unknown,ico_dev_unknown);

    branch = tree->appendItem(top,"Ports (COM & LPT)",ico_dev_serial,ico_dev_serial);
    FXTreeItem* devSound = tree->appendItem(top,"Sound, video and game controllers",ico_dev_sound,ico_dev_sound);
    branch = tree->appendItem(top,"Storage volumes",ico_dev_disk,ico_dev_disk);

    FXTreeItem* devSystem = tree->appendItem(top,"System devices",ico_dev_computer,ico_dev_computer);    
      //tree->appendItem(branch,computerType,ico_dev_computer,ico_dev_computer);

    char monitors[512];
    getMonitors(monitors, sizeof(monitors));
    if (!getMonitors(monitors, sizeof(monitors))) {
	char* monitortok = strtok(monitors, ",");

      while (monitortok) {
        tree->appendItem(devMonitors,monitortok,ico_dev_disp,ico_dev_disp);
        monitortok = strtok(NULL, ",");
      }
    } else { 
      tree->appendItem(devMonitors,"Default Monitor",ico_dev_disp,ico_dev_disp);

    }
    //puts(monitors);

    for (dev = pciaccess->devices; dev; dev = dev->next) {
      pci_fill_info(dev, PCI_FILL_IDENT | PCI_FILL_BASES | PCI_FILL_CLASS);
      pci_lookup_name(pciaccess, namebuf, sizeof(namebuf), PCI_LOOKUP_VENDOR|PCI_LOOKUP_DEVICE, dev->vendor_id, dev->device_id);

      if ((dev->device_class >> 8) == PCI_BASE_CLASS_NETWORK) {
        //printf("%s\n", namebuf);
        tree->appendItem(devNetwork, namebuf, ico_dev_network, ico_dev_network);
      } else if ((dev->device_class >> 8) == PCI_BASE_CLASS_STORAGE && dev->device_class != PCI_CLASS_STORAGE_FLOPPY) {
        tree->appendItem(devStorage, namebuf, ico_dev_ide, ico_dev_ide);
	} else if (dev->device_class == PCI_CLASS_STORAGE_FLOPPY) {
        tree->appendItem(devStorage, namebuf, ico_dev_ide, ico_dev_ide);
	} else if ((dev->device_class >> 8) == PCI_BASE_CLASS_MULTIMEDIA) {
        tree->appendItem(devSound, namebuf, ico_dev_sound, ico_dev_sound);
	} else if ((dev->device_class >> 8) == PCI_BASE_CLASS_BRIDGE) {
        tree->appendItem(devSystem, namebuf, ico_dev_computer, ico_dev_computer);
	} else if ((dev->device_class >> 8) == PCI_CLASS_OTHERS) {
        tree->appendItem(devUnknown, namebuf, ico_dev_unknown, ico_dev_unknown);
	}
    }

    FXTreeItem* loopthruprev;
    FXTreeItem* loopthru = top->getFirst();

    int i = 0;

    while (loopthru) {

	i++;

	loopthruprev = loopthru;
	loopthru = loopthru->getNext();

	if (!loopthruprev->getNumChildren()) {
	  tree->removeItem(loopthruprev);
	  //delete loopthru;
	  //puts("No");
	}

	//printf("%d\n", i);
	if (loopthruprev == top)
	  break;



    }



  //new FXButton(toolbar,"\tUp",ico_hist_up,NULL,0,BUTTON_TOOLBAR|FRAME_RAISED|LAYOUT_TOP|LAYOUT_LEFT,0,0,0,0,  0,0,0,0);

}


int main(int argc,char *argv[]) {


  FXApp application("sysdm", "Ice2KProj");
  app = &application;

  application.init(argc,argv);

  ico_devmgmt = new FXGIFIcon(app, resico_devmgmt);
  
  sysdmwin = new SystemPropertiesWindow(&application);

  // create windows
  application.create();
  sysdmwin->killFocus();

  sysdmwin->show(PLACEMENT_OWNER);
  sysdmwin->killFocus();

  sysdmwin->changeFocus((FXWindow*)0);

  //sysdmwin->changeFocus(sysdmwin);


  //sysdmwin->show(PLACEMENT_SCREEN);

  // Run the application
  return application.run();
}

